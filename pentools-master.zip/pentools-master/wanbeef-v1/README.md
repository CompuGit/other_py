WANBEEF Version 1.0 Released on 5/6/20
--------------------------------------

-> This is an open source project framework for apache and beef services
   for penetration testing.

-> This program uses python3 scripting to get tunnel services for the
   localhost ports 80 and 3000.

-> ngrok.io and serveo.net are the only two services provided.

-> If want to how to use this please use command as below -

	# ./wanbeef help

-> To start ngrok tunnel services please use command as below -

	# ./wanbeef ngrok

-> To start serveo tunnel services please use command as below -

	# ./wanbeef serveo

--------------------------------------

$$$ Developed by Poorna Venkata Sai (CompuGit Admin) $$$

https://github.com/CompuGit/pentools/tree/master/wanbeef-v1

