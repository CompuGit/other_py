class Node:
    def __init__(self, cnt='', atts={}):
        self.__atts = atts
        self.__cnt = cnt
        self.__childs = []
        self.__parent = None
        self.tag = None

    def html(self):
        atts = ' '.join(f'{key}="{value}"' for key, value in self.__atts.items())
        if atts:
            atts = ' ' + atts

        childs = ''.join(child.html() for child in self.__childs)

        return self.tag %(atts, self.__cnt, childs)

    def appendChild(self, child):
        child.__parent = self
        self.__childs.append(child)


class Html(Node):
    def __init__(self, cnt='', atts={}):
        super().__init__(cnt, atts)
        self.tag = '<!DOCTYPE html><html%s>%s%s</html>'

class Head(Node):
    def __init__(self, cnt='', atts={}):
        super().__init__(cnt, atts)
        self.tag = '<head%s>%s%s</head>'

class Title(Node):
    def __init__(self, cnt='', atts={}):
        super().__init__(cnt, atts)
        self.tag = '<title%s>%s%s</title>'

class Body(Node):
    def __init__(self, cnt='', atts={}):
        super().__init__(cnt, atts)
        self.tag = '<body%s>%s%s</body>'

class Div(Node):
    def __init__(self, cnt='', atts={}):
        super().__init__(cnt, atts)
        self.tag = '<div%s>%s%s</div>'

class B(Node):
    def __init__(self, cnt='', atts={}):
        super().__init__(cnt, atts)
        self.tag = '<b%s>%s%s</b>'



def main():

    divAtts = {}
    divAtts['id'] = 'first'
    divAtts['class'] = 'foo'
    divA = Div('This is a test A', divAtts)

    divAtts = {}
    divAtts['id'] = 'second'
    divAtts['class'] = 'bar'
    divB = Div('This is a test B', divAtts)

    divAtts = {}
    divAtts['id'] = 'third'
    divAtts['class'] = 'dump'
    divC = Div('This is a test C', divAtts)
    
    b = B('This is a simple HTML file')
    divC.appendChild(b)

    body = Body()
    body.appendChild(divA)
    body.appendChild(divB)
    body.appendChild(divC)


    title = Title('Example')

    head = Head()
    head.appendChild(title)

    htmlAtts = {}
    htmlAtts['lang'] = 'en'
    html = Html('', htmlAtts)

    html.appendChild(head)
    html.appendChild(body)

    print(html.html())

if __name__=='__main__':
    main()