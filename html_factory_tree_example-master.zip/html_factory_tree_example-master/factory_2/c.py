from a import *

class AbstractNodeFactory:
    def makeNode(self, tag, cnt='', atts={}):
        pass


class StandardNodeFactory(AbstractNodeFactory):
    def makeNode(self, tag, cnt='', atts={}):
        tags = ['html', 'head', 'title', 'body', 'div', 'b']

        if tag in tags:
            return eval(f'{tag.capitalize()}(cnt, atts)')
        else:
            return Node(cnt, atts)

class DebugNodeFactory(StandardNodeFactory):
    
    @staticmethod
    def debug(func):
        def wrapper(*args, **kwargs):
            node = func(*args, **kwargs)
            if node:
                print(f"{args[1].capitalize()} node is created.")
            return node
        return wrapper

    @debug
    def makeNode(self, tag, cnt='', atts={}):
        return super().makeNode(tag, cnt, atts)


def main():
    factory = DebugNodeFactory()

    divAtts = {}
    divAtts['id'] = 'first'
    divAtts['class'] = 'foo'
    divA = factory.makeNode('div', 'This is a test A', divAtts)

    divAtts = {}
    divAtts['id'] = 'second'
    divAtts['class'] = 'bar'
    divB = factory.makeNode('div', 'This is a test B', divAtts)

    divAtts = {}
    divAtts['id'] = 'third'
    divAtts['class'] = 'dump'
    divC = factory.makeNode('div', 'This is a test C', divAtts)

    b = factory.makeNode('b', 'This is a simple HTML file')
    divC.appendChild(b)

    body = factory.makeNode('body')
    body.appendChild(divA)
    body.appendChild(divB)
    body.appendChild(divC)

    title = factory.makeNode('title', 'Example')

    head = factory.makeNode('head')
    head.appendChild(title)

    htmlAtts = {}
    htmlAtts['lang'] = 'en'
    html = factory.makeNode('html', atts=htmlAtts)


    html.appendChild(head)
    html.appendChild(body)

    print(html.html())

if __name__=='__main__':
    main()