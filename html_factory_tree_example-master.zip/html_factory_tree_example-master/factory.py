class AbstractNodeFactory:
    def makeNode(self, tag, content='', attributes={}, children=None):
        pass


class StandardNodeFactory(AbstractNodeFactory):
    def makeNode(self, tag, content='', attributes={}, children=None):
        if tag == 'html':
            return Html(content, attributes, children)
        elif tag == 'head':
            return Head(content, attributes, children)
        elif tag == 'title':
            return Title(content, attributes, children)
        elif tag == 'body':
            return Body(content, attributes, children)
        elif tag == 'div':
            return Div(content, attributes, children)
        elif tag == 'b':
            return B(content, attributes, children)
        else:
            return Node(content, attributes, children)


class DebugNodeFactory(AbstractNodeFactory):
    def __init__(self, factory):
        self.factory = factory

    def makeNode(self, tag, content='', attributes={}, children=None):
        print(f"{tag.capitalize()} node is created.")
        return self.factory.makeNode(tag, content, attributes, children)




class Node:
    def __init__(self, content='', attributes={}, children=None):
        self.__attributes = attributes
        self.__content = content
        self.__children = children if children is not None else []
        self.parent = None
        self.tag = None

    def html(self):
        attributes = ' '.join( [ f'{k}="{v}"' for k,v in self.__attributes.items() ] )
        if attributes:
            attributes = ' '+attributes

        children = []

        if self.__children:
            for child in self.__children:
                children.append(child.html())
        
        children = ''.join(children)

        return self.tag.format(attributes=attributes, content=self.__content, children=children)

    def appendChild(self, child):
        child.parent = self
        self.__children.append(child)


class Html(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<!DOCTYPE html><html{attributes}>{content}{children}</html>'

class Head(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<head{attributes}>{content}{children}</head>'

class Title(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<title{attributes}>{content}{children}</title>'

class Body(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<body{attributes}>{content}{children}</body>'

class Div(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<div{attributes}>{content}{children}</div>'

class B(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<b{attributes}>{content}{children}</b>'




def main():

    #factory = StandardNodeFactory()
    factory = DebugNodeFactory(StandardNodeFactory())


    divAtts = {}
    divAtts['id'] = 'first'
    divAtts['class'] = 'foo'
    #divA = Div('This is a test A', divAtts)
    divA = factory.makeNode('div', 'This is a test A', divAtts)

    divAtts = {}
    divAtts['id'] = 'second'
    divAtts['class'] = 'bar'
    #divB = Div('This is a test B', divAtts)
    divB = factory.makeNode('div', 'This is a test B', divAtts)

    divAtts = {}
    divAtts['id'] = 'third'
    divAtts['class'] = 'dump'
    #divC = Div('This is a test C', divAtts)
    divC = factory.makeNode('div', 'This is a test C', divAtts)

    #b = B('This is a simple HTML file')
    b = factory.makeNode('b', 'This is a simple HTML file')
    divC.appendChild(b)

    #body = Body()
    body = factory.makeNode('body')
    body.appendChild(divA)
    body.appendChild(divB)
    body.appendChild(divC)

    #title = Title('Example')
    title = factory.makeNode('title', 'Example')

    #head = Head()
    head = factory.makeNode('head')
    head.appendChild(title)

    htmlAtts = {}
    htmlAtts['lang'] = 'en'
    #html = Html('', htmlAtts)
    html = factory.makeNode('html', attributes=htmlAtts)


    html.appendChild(head)
    html.appendChild(body)

    print(html.html())

if __name__=='__main__':
    main()