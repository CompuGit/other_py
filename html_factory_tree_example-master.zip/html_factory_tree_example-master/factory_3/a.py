class Node:
    def __init__(self, content='', attributes={}):
        self.__attributes = attributes
        self.__content = content
        self.__childs = []
        self.parent = None
        self.tag = None

    def html(self):
        attributes_list = []
        
        for attribute_name, attribute_value in self.__attributes.items():
            attributes_list.append(f'{attribute_name}="{attribute_value}"')
        
        attributes = ' '.join(attributes_list)

        if attributes: attributes = ' ' + attributes

        childs = []
        for child in self.__childs:
            childs.append(child.html())
        
        childs = ''.join(childs)

        return self.start_tag + attributes +'>' + self.__content + childs + self.end_tag

    def appendChild(self, child):
        child.parent = self
        self.__childs.append(child)


class Html(Node):
    def __init__(self, content='', attributes={}):
        super().__init__(content, attributes)
        self.start_tag = '<!DOCTYPE html><html'
        self.end_tag = '</html>'

class Head(Node):
    def __init__(self, content='', attributes={}):
        super().__init__(content, attributes)
        self.start_tag = '<head'
        self.end_tag = '</head>'

class Title(Node):
    def __init__(self, content='', attributes={}):
        super().__init__(content, attributes)
        self.start_tag = '<title'
        self.end_tag = '</title>'

class Body(Node):
    def __init__(self, content='', attributes={}):
        super().__init__(content, attributes)
        self.start_tag = '<body'
        self.end_tag = '</body>'

class Div(Node):
    def __init__(self, content='', attributes={}):
        super().__init__(content, attributes)
        self.start_tag = '<div'
        self.end_tag = '</div>'

class B(Node):
    def __init__(self, content='', attributes={}):
        super().__init__(content, attributes)
        self.start_tag = '<b'
        self.end_tag = '</b'


def main():

    divAtts = {}
    divAtts['id'] = 'first'
    divAtts['class'] = 'foo'
    divA = Div('This is a test A', divAtts)

    divAtts = {}
    divAtts['id'] = 'second'
    divAtts['class'] = 'bar'
    divB = Div('This is a test B', divAtts)

    divAtts = {}
    divAtts['id'] = 'third'
    divAtts['class'] = 'dump'
    divC = Div('This is a test C', divAtts)
    
    b = B('This is a simple HTML file')
    divC.appendChild(b)

    body = Body()
    body.appendChild(divA)
    body.appendChild(divB)
    body.appendChild(divC)


    title = Title('Example')

    head = Head()
    head.appendChild(title)

    htmlAtts = {}
    htmlAtts['lang'] = 'en'
    html = Html('', htmlAtts)

    html.appendChild(head)
    html.appendChild(body)

    print(html.html())

if __name__=='__main__':
    main()