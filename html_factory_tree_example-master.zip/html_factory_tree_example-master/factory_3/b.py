from a import *

class AbstractNodeFactory:
    def makeNode(self, tag, content='', attributes={}):
        pass


class StandardNodeFactory(AbstractNodeFactory):
    TAG_MAP = {
        'html': Html,
        'head': Head,
        'title': Title,
        'body': Body,
        'div': Div,
        'b': B,
    }

    def makeNode(self, tag, content='', attributes={}):
        cls = self.TAG_MAP.get(tag, Node)
        return cls(content, attributes)



def main():

    factory = StandardNodeFactory()


    divAtts = {}
    divAtts['id'] = 'first'
    divAtts['class'] = 'foo'
    divA = factory.makeNode('div', 'This is a test A', divAtts)

    divAtts = {}
    divAtts['id'] = 'second'
    divAtts['class'] = 'bar'
    divB = factory.makeNode('div', 'This is a test B', divAtts)

    divAtts = {}
    divAtts['id'] = 'third'
    divAtts['class'] = 'dump'
    divC = factory.makeNode('div', 'This is a test C', divAtts)

    b = factory.makeNode('b', 'This is a simple HTML file')
    divC.appendChild(b)

    body = factory.makeNode('body')
    body.appendChild(divA)
    body.appendChild(divB)
    body.appendChild(divC)

    title = factory.makeNode('title', 'Example')

    head = factory.makeNode('head')
    head.appendChild(title)

    htmlAtts = {}
    htmlAtts['lang'] = 'en'
    html = factory.makeNode('html', attributes=htmlAtts)


    html.appendChild(head)
    html.appendChild(body)

    print(html.html())

if __name__=='__main__':
    main()