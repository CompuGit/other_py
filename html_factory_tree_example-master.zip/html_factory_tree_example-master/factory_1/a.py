class Node:
    def __init__(self, content='', attributes={}, children=None):
        self.__attributes = attributes
        self.__content = content
        self.__children = children if children is not None else []
        self.parent = None
        self.tag = None

    def html(self):
        attributes = ' '.join( [ f'{k}="{v}"' for k,v in self.__attributes.items() ] )
        if attributes:
            attributes = ' '+attributes

        children = []

        if self.__children:
            for child in self.__children:
                children.append(child.html())
        
        children = ''.join(children)

        return self.tag.format(attributes=attributes, content=self.__content, children=children)

    def appendChild(self, child):
        child.parent = self
        self.__children.append(child)


class Html(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<!DOCTYPE html><html{attributes}>{content}{children}</html>'

class Head(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<head{attributes}>{content}{children}</head>'

class Title(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<title{attributes}>{content}{children}</title>'

class Body(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<body{attributes}>{content}{children}</body>'

class Div(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<div{attributes}>{content}{children}</div>'

class B(Node):
    def __init__(self, content='', attributes={}, children=[]):
        super().__init__(content, attributes, children)
        self.tag = '<b{attributes}>{content}{children}</b>'




def main():

    divAtts = {}
    divAtts['id'] = 'first'
    divAtts['class'] = 'foo'
    divA = Div('This is a test A', divAtts)

    divAtts = {}
    divAtts['id'] = 'second'
    divAtts['class'] = 'bar'
    divB = Div('This is a test B', divAtts)

    divAtts = {}
    divAtts['id'] = 'third'
    divAtts['class'] = 'dump'
    divC = Div('This is a test C', divAtts)
    
    b = B('This is a simple HTML file')
    divC.appendChild(b)

    body = Body()
    body.appendChild(divA)
    body.appendChild(divB)
    body.appendChild(divC)


    title = Title('Example')

    head = Head()
    head.appendChild(title)

    htmlAtts = {}
    htmlAtts['lang'] = 'en'
    html = Html('', htmlAtts)

    html.appendChild(head)
    html.appendChild(body)

    print(html.html())

if __name__=='__main__':
    '''
     a) Implement the class hierarchy and use the following to test it

    Expected output:
    <!DOCTYPE html><html lang="en"><head><title>Example</title></head><body><div id="first" class="foo">This is a test A</div>
    <div id="second" class="bar">This is a test B</div><div id="third" class="dump"><b>This is a simple HTMLfile</b>
    This is a test C</div></body></html>
    '''
    main()