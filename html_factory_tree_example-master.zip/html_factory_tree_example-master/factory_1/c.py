from b import *


class DebugNodeFactory(AbstractNodeFactory):
    def __init__(self, factory):
        self.factory = factory

    def makeNode(self, tag, content='', attributes={}, children=None):
        print(f"{tag.capitalize()} node is created.")
        return self.factory.makeNode(tag, content, attributes, children)



def main():

    factory = DebugNodeFactory(StandardNodeFactory())


    divAtts = {}
    divAtts['id'] = 'first'
    divAtts['class'] = 'foo'
    divA = factory.makeNode('div', 'This is a test A', divAtts)

    divAtts = {}
    divAtts['id'] = 'second'
    divAtts['class'] = 'bar'
    divB = factory.makeNode('div', 'This is a test B', divAtts)

    divAtts = {}
    divAtts['id'] = 'third'
    divAtts['class'] = 'dump'
    divC = factory.makeNode('div', 'This is a test C', divAtts)

    b = factory.makeNode('b', 'This is a simple HTML file')
    divC.appendChild(b)

    body = factory.makeNode('body')
    body.appendChild(divA)
    body.appendChild(divB)
    body.appendChild(divC)

    title = factory.makeNode('title', 'Example')

    head = factory.makeNode('head')
    head.appendChild(title)

    htmlAtts = {}
    htmlAtts['lang'] = 'en'
    html = factory.makeNode('html', attributes=htmlAtts)


    html.appendChild(head)
    html.appendChild(body)

    print(html.html())

if __name__=='__main__':
 
    '''
    c) Now define a DebugNodeFactory that class defines another concrete factory which prints the textual
    representation of each node during its creation.

    Expected output:
    Div node is created.
    Div node is created.
    Div node is created.
    B node is created.
    Body node is created.
    Title node is created.
    Head node is created.
    Html node is created.
    <!DOCTYPE html><html lang="en"><head><title>Example</title></head><body><div id="first" class="foo">This is a test A</div>
    <div id="second" class="bar">This is a test B</div><div id="third" class="dump">This is a test C<b>This is a simple HTML file</b>
    </div></body></html>

    '''
    main()