from main import *

def operations(choice):
        #employees operations
        if choice=='1':
            print(format(' Create Employee ', '#^30'))
            firstname = input('    Enter Firstname : ')
            lastname = input('    Enter Lastname : ')
            department_name = choose_department()
            rank = input('    Etner Rank : ')
            Employee.create(firstname=firstname, lastname=lastname, department_name = department_name, rank=rank)
            print(format('', '=^30'),'\n')

        elif choice=='2':
            print(format(' Modify Employee ', '#^30'))
            employee_id = int(input('    Enter Employee ID : '))
            firstname = input('    Enter Firstname (if not required leave blank): ')
            lastname = input('    Enter Lastname (if not required leave blank): ')
            department_name = choose_department()
            rank = input('    Enter Rank (if not required leave blank): ')
            Employee.modify(employee_id=employee_id, firstname=firstname, lastname=lastname, department_name = department_name, rank=rank)
            print(format('', '=^30'),'\n')

        elif choice=='3':
            print(format(' Find Employee ', '#^30'))
            employee_id = int(input('    Enter Employee ID : '))
            d = Employee.find(employee_id=employee_id)
            print()
            for k,v in d.items():
                print(k,':',v)
            print(format('', '=^30'),'\n')
        
        elif choice=='4':
            print(format(' Remove Employee ', '#^30'))
            employee_id = int(input('    Enter Employee ID : '))
            ch = input('    Are you sure removing the Employee? (Y/N) : ')
            if ch.lower()=='y':
                Employee.remove(employee_id=employee_id)
            print(format('', '=^30'),'\n')
    
        elif choice=='5':
            print(format(' Create Department ', '#^30'))
            department_name = input('    Enter Department Name : ')
            n = int(input('    Enter how amy Budgets categories you need to enter : '))
            budgets = {}
            for i in range(n):
                category = input('        Enter Category Name : ')
                amt = int(input('        Enter Budget : '))
                budgets[category] = amt
            
            Department.create(department_name=department_name, budgets=budgets)
            print(format('', '=^30'),'\n')

        elif choice=='6':
            print(format(' Modify Department ', '#^30'))
            department_name = choose_department()
            budgets = Department.dept_budgets[['category','amount']][Department.dept_budgets['department_name']==department_name].to_dict('records')

            for budget in budgets:
                category = budget['category']
                amount = budget['amount']
                amount = input(f'    {category} (amount={amount}) : ')
                amount = budget['amount'] if not amount else int(amount)
                budget['amount'] = amount

            Department.modify(department_name=department_name, budgets=budgets)
            print(format('', '=^30'),'\n')

        elif choice=='7':
            print(format(' Find Department ', '#^30'))
            department_name = choose_department()
            d = Department.find(department_name=department_name)
            print()
            for k,v in d.items():
                if type(v) in [dict]:
                    print(k,':')
                    for m,n in v.items():
                        print('  ',m,':',n)
                else:
                    print(k,':',v)
            print(format('', '=^30'),'\n')
        
        elif choice=='8':
            print(format(' Remove Department ', '#^30'))
            department_name = choose_department()
            ch = input('    Are you sure removing the department? all the employees associated with this department are also removed. (Y/N) : ')
            if ch.lower()=='y':
                Department.remove(department_name=department_name)
            print(format('', '=^30'),'\n')
        
        elif choice=='9':
            print(format(' Budgets for all Categories ', '#^30'))
            l=Budget.view()
            print()
            for d in l:
                for k,v in d.items():
                    if type(v) in [dict]:
                        print(k,':')
                        for m,n in v.items():
                            print('  ',m,':',n)
                        print()
                    else:
                        print(k,':',v[0])
            print(format('', '=^30'),'\n')
        
        elif choice=='10':
            print(format(' Update Budget for a Category ', '#^30'))
            category = choose_category(flag=1)
            percent = int(input('    Enter percentage number with sign : '))
            Budget.update_budget(category, percent)
            print(' [*] Budgets Updated.')
            print(format('', '=^30'),'\n')
        
        elif choice=='11':
            print(format(' Update Budget for all Categories ', '#^30'))
            percent = int(input('    Enter percentage number with sign : '))
            Budget.update_budget(percent=percent)
            print(' [*] Budgets Updated.')
            print(format('', '=^30'),'\n')
    
        elif choice=='12':
            print(format(' Create an Expense ', '#^30'))
            employee_id = int(input('    Enter Employee Id : '))
            department_name = Employee.find(employee_id)['department_name']
            print(f'    Department Name : {department_name}')
            category = choose_category(department_name)
            amount = int(input('    Enter Expense Amount : '))
            today = datetime.today()
            timestamp =  datetime.timestamp(datetime.strptime(date_str, "%m-%d-%Y")) if (date_str:=input(f'        Enter Date(mm-dd-yyyy) when the expense made?  (defaut= {today}) : ')) else datetime.timestamp(today)
            Expense.create_expense(employee_id, department_name, category, amount, timestamp)
            print(format('', '#^30'),'\n')
        
        elif choice=='13':
            print(format(' Search Expenses ', '#^30'))
            category = choose_category()
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            l = Expense.search_expense(category=category,month=month)
            for d in l:
                print()
                for k,v in d.items():
                    print(k,':',v)
            print(format('', '=^30'),'\n')

        elif choice=='14':
            print(format(' Maximux Expense Employee ', '#^30'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            l=Expense.max_expense_emp(month=month)
            print()
            for d in l:
                for k,v in d.items():
                    print(k,':',v)
            print(format('', '=^30'),'\n')
        
        elif choice=='16':
            print(format(' Over Budget Departments ', '#^30'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            d=Expense.over_budget_dep(month=month)
            print()
            for k,v in d.items():
                print(k,':',v)
            print(format('', '=^30'),'\n')
        
        elif choice=='15':
            print(format(' Maximum Expense Department ', '#^30'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.max_expense_dep(month=month))
            print(format('', '=^30'),'\n')
        
        elif choice=='17':
            print(format(' Generate Monthly Expense Report ', '#^30'))
            department_name = choose_department(flag=1)
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.expense_report_gen(department_name=department_name, month=month))
            print(' [*] Report Generated.')
            print(format('', '=^30'),'\n')
        
        elif choice=='18':
            print(format(' Generate Monthly Summary Report ', '#^30'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.summary_report_gen(month=month))
            print(' [*] Report Generated.')
            print(format('', '=^30'),'\n')     
    
        elif choice=='19':
            print(format(' Expense Category Total Counts', '#^30'))
            department_name = choose_department(flag=1)
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            Histogram.expenses_counts(department_name=department_name, month=month)
            print(' [*] Histogram Created.')
            print(format('', '=^30'),'\n')
        
        elif choice=='20':
            print(format(' Department Total Expense ', '#^30'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            Histogram.expenses_totals(month=month)
            print(' [*] Histogram Created.')
            print(format('', '=^30'),'\n')
        
        elif choice=='21':
            print(format(' Employee Total Expense ', '#^30'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            Histogram.expenses_employees(month=month)
            print(' [*] Histogram Created.')
            print(format('', '=^30'),'\n')


def choose_department(flag=0):
    if not flag:
        departments = Department.dept_budgets['department_name'].unique().tolist()
        print(' Choose a Department : ')
    else:
        departments =  Expense.expenses['department_name'].unique().tolist()
        print(' Choose a Department from Expenses till: ')

    i=1
    for dep in departments:
        print(f'  {i}. {dep}')
        i+=1
        
    while True:
        choice = int(x) if (x:=input(' >> ')) else 0
        if choice: break
        else: print('< Invalid Choice >')
    return list(departments)[choice-1]


def choose_category(department_name=None, flag=0):
    if department_name:
        df = Department.dept_budgets.groupby('department_name').get_group(department_name)
        categories = df['category'].unique().tolist()
        print(' Choose an Expense Category in the Department : ')
    elif not department_name and not flag:
        categories = Expense.expenses['category'].unique().tolist()
        print(' Choose an Expense Category from Expenses till: ')
    elif flag:
        categories = Department.dept_budgets['category'].unique().tolist()
        print(' Choose an Expense Category in all Departments : ')
    i=1
    for cat in categories:
        print(f'        {i}. {cat}')
        i+=1
    
    while True:
        choice = int(x) if (x:=input(' >> ')) else 0
        if choice: break
        else: print('< Invalid Choice >')

    return categories[choice-1]



if __name__=='__main__':

    print(format(' Expense Tracker ', '#^30'))
    print()

    choice = '1'
    while True:
        print('''
    Main Menu (choose any option)
        
    1. Create New Employee Record
    2. Modify an Employee Record 
    3. Find an Employee Record
    4. Remove an Employee Record
    5. Create New Department its Budgets Record
    6. Modify a Department Record
    7. Find a Department Record
    8. Remove a Department Record
    9. View Budgets for a Department
    10. Update Budgets for all by one category
    11. Update Budgets for all Categories
    12. Create an Expense
    13. Search an Expense by category and month
    14. Find maximum Expense Employee for a given month
    15. Find maximum Expense Department for a given month
    16. Find Over bugets Departmetns for given month
    17. Generate Monthly Expense Report
    18. Generate monthly Summary Expenses report
    19. Create Histogram for Total Counts for each expense category given month
    20. Create Histogram for Department Total epsense in a month
    21. Create Histogram for Employee Total expense in a month

    q / quit to exit the application
        ''')
        choice = input(' >> ')
        if choice in ['q', 'quit']:
            print('Application data saved. Quitting...')
            break
        operations(choice)