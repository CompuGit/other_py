from main import *

if __name__=='__main__':
    pass
    #print(Employee.find(employee_id=1))
    #Employee.create(firstname='Clark', lastname='Kent', department_name='Engineering', rank='Supervisor')
    #Employee.modify(employee_id=4, firstname='Clark', lastname='Denvers', department_name='Sales')
    #Employee.remove(employee_id=4)

    #print(Department.find('Sales'))
    #Department.create('Accounting')
    #Department.modify('Accounting', budgets={'Transportation':500})
    #Department.remove('Sales')
    
    #Expense.create_expense(employee_id=2, department_name='Engineering', category='Transportation', amount=400)
    #print(Expense.search_expense(department_name='Sales'))
    #Expense.expense_report_gen('Engineering', month=3)
    #Expense.summary_report_gen(month=3)
    #print(Expense.max_expenses_emp(month=4))
    #print(Expense.over_budget_dep(month=4))
    #print(Expense.max_expense_dep(month=4))

    #Budget.update_budget(category='Transportation', percent=-10)
    #Budget.update_budget(percent=-10)

    #Histogram.expenses_counts('Engineering', month=3)
    #Histogram.expenses_totals(month=3)
    #Histogram.expenses_employees(month=4)