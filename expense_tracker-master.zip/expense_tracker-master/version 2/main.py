import json
from time import time
from datetime import datetime, date
import json, copy
import matplotlib.pyplot as plt
import pandas as pd

class Department:

    dept_budgets_file = './data/dept_budgets.csv'
    dept_budgets = pd.read_csv(dept_budgets_file)

    def __init__(self):
        raise TypeError("[!] Class cannot be instantiated.")

    @classmethod
    def find(cls, department_name):
        emps = Employee.employees['employee_id'][Employee.employees['department_name']==department_name].dropna().tolist()
        budgets = cls.dept_budgets[cls.dept_budgets['department_name'] == department_name].set_index('category')['amount'].to_dict()
        return {'employees': emps, 'budgets': budgets}

    @classmethod
    def create(cls, department_name, budgets):
        for category, amount in budgets.items():
            cls.dept_budgets = cls.dept_budgets._append({'department_name': department_name, 'category': category, 'amount': amount}, ignore_index=True)
        
        print('Department created : ',department_name)
        return cls.save()

    @classmethod
    def modify(cls, department_name, budgets):
        cls.dept_budgets = cls.dept_budgets[cls.dept_budgets['department_name'] != department_name]
        for budget in budgets:
            category = budget['category']
            amount = budget['amount']
            cls.dept_budgets = cls.dept_budgets._append({'department_name': department_name, 'category': category, 'amount': amount}, ignore_index=True)
        
        print('Department Modified : ',department_name)  
        
        return cls.save()
    
    @classmethod
    def remove(cls, department_name):
        employee_ids = Employee.employees['employee_id'][Employee.employees['department_name']==department_name].dropna().tolist()
        for employee_id in employee_ids:
            Employee.remove(employee_id)
        
        cls.dept_budgets = cls.dept_budgets[cls.dept_budgets['department_name'] != department_name]
        
        print('Department Removed : ',department_name)
        return cls.save()
    
    @classmethod
    def save(cls):
        try:
            cls.dept_budgets.to_csv(cls.dept_budgets_file, index=False)
            return True
        except Exception as e:
            print(e)
            return False

class Employee:
    employees_file = './data/employees.csv'
    employees = pd.read_csv(employees_file)

    def __init__(self):
        raise TypeError("[!] Class cannot be instantiated.")

    @classmethod
    def find(cls, employee_id):
        emp = cls.employees.loc[cls.employees['employee_id'] == employee_id]
        if not emp.empty:
            return emp.to_dict('records')[0]
        else:
            raise ValueError('[!] employee id not found.')

    @classmethod
    def create(cls, **kwargs):
        emp = pd.DataFrame({
            'employee_id': [cls.employees['employee_id'].max() + 1],
            **kwargs
        })
        cls.employees = pd.concat([cls.employees, emp], ignore_index=True)

        print()
        print('Employee created with id : ',emp['employee_id'].iloc[0])
        cls.save()

    @classmethod
    def modify(cls, employee_id, **kwargs):
        emp = cls.find(employee_id)
        emp_index = cls.employees.index[cls.employees['employee_id'] == employee_id][0]
                
        for k,v in kwargs.items():
            if v:
                cls.employees.loc[emp_index, k] = v
        
        print('Employee Modified with id : ',emp['employee_id'])
        cls.save()
    
    @classmethod
    def remove(cls, employee_id):
        emp_index = cls.employees.index[cls.employees['employee_id'] == employee_id][0]
        cls.employees.drop(emp_index, inplace=True)

        print('Employee Removed with id : ',employee_id)
        cls.save()
    
    @classmethod
    def save(cls):
        try:
            cls.employees.to_csv(cls.employees_file, index=False)
            return True
        except Exception as e:
            print(e)
            return False

class Expense:
    expenses_file = './data/expenses.csv'
    expenses = pd.read_csv(expenses_file)

    dept_budgets = Department.dept_budgets

    def __init__(self):
        raise TypeError("[!] Class cannot be instantiated.")
    
    @classmethod
    def create_expense(cls, employee_id, department_name, category, amount, timestamp=time()):
        expense = pd.DataFrame({
            'employee_id': [employee_id],
            'department_name': [department_name],
            'category': [category],
            'amount': [amount],
            'timestamp': [timestamp]
        })
        
        cls.expenses = cls.expenses._append(expense)
        cls.expenses.to_csv(cls.expenses_file, index=False)
    
    
    @classmethod
    def search_expense(cls, category=None, department_name=None, month=datetime.today().month):
        expenses_list = copy.deepcopy(cls.expenses)
        
        if category:
            expenses_list = expenses_list[expenses_list['category'] == category]
        
        if department_name:
            expenses_list = expenses_list[expenses_list['department_name'] == department_name]
        
        expenses_list['timestamp'] = pd.to_datetime(expenses_list['timestamp'], unit='s').dt.strftime('%d-%m-%Y %H:%M:%S')
        
        if month:
            expenses_list = expenses_list[pd.to_datetime(expenses_list['timestamp'], format='%d-%m-%Y %H:%M:%S').dt.month == month]        

        return expenses_list.to_dict('records')

    @classmethod
    def expense_report_gen(cls, department_name, month=datetime.today().month):
        report = cls.search_expense(department_name=department_name, month=month)
        cls.save(f'./data/{department_name}_{month}_expense_report_.csv', report, ['employee_id', 'amount'])
   
    @classmethod
    def summary_report_gen(cls, month=datetime.today().month):
        report = cls.search_expense(month=month)
        cls.save(f'./data/{month}_summary_report_.csv', report, ['department_name','category','amount'])


    @classmethod
    def max_expense_emp(cls, month=datetime.today().month):
        report = cls.search_expense(month=month)
        report = pd.DataFrame(report)
        report = report[['employee_id','amount']][report['amount']==report.amount.max()]
        return report.to_dict('records')
    
    @classmethod
    def over_budget_dep(cls, month=datetime.today().month):
        _expenses = pd.DataFrame(cls.search_expense(month=month))
        _expenses = _expenses[['department_name','category','amount']]
        _budgets = cls.dept_budgets

        result = {}
        for dept in _expenses['department_name'].unique():
            expenses_dept = _expenses[_expenses['department_name'] == dept]
            budgets_dept = _budgets[_budgets['department_name'] == dept]

            merged = expenses_dept.merge(budgets_dept, on='category', suffixes=('_expenses', '_budgets'))
            filtered = merged[merged['amount_expenses'] >= merged['amount_budgets']]
            categories = filtered['category'].tolist()
            if categories:
                result[dept] = categories

        return result

    @classmethod
    def max_expense_dep(cls, month=datetime.today().month):
        _expenses = pd.DataFrame(cls.search_expense(month=month))
        grouped = _expenses.groupby('department_name').sum()
        max_dept = grouped['amount'].idxmax()
        return max_dept

    @classmethod
    def save(cls, filename, report, columns):
        try:
            df = pd.DataFrame(report)
            df = df[columns]
            df.to_csv(filename, index=False)
            return True
        except Exception as e:
            print(e)
            return False

class Budget:

    @classmethod
    def update_budget(cls, category=None, percent=0):
        old_dept_budgets = copy.deepcopy(Department.dept_budgets)
        if category:
            Department.dept_budgets.loc[Department.dept_budgets['category'] == category, 'amount'] *= (1 + percent/100)
        else:
            Department.dept_budgets['amount'] *= (1 + percent/100)
        
        old_dept_budgets.to_csv('./data/old/dept_budgets.csv', index=False)
        Department.dept_budgets.to_csv('./data/dept_budgets.csv', index=False)
    
    @classmethod
    def view(cls):
        depts = list(Department.dept_budgets.groupby('department_name')['department_name'].unique().tolist())
        result = []
        for dept in depts:
            budgets = Department.dept_budgets.groupby('department_name').get_group(dept[0]).set_index('category')['amount'].to_dict()
            result.append( {'department_name': dept, 'budgets':budgets} )
        return result

class Histogram:
    @classmethod
    def expenses_counts(cls, department_name, month=datetime.today().month):
        report = Expense.search_expense(department_name=department_name, month=month)
        df = pd.DataFrame(report)
        grouped_data = df.groupby('category')['amount'].count()
        
        plt.bar(grouped_data.index, grouped_data.values, alpha=0.5, color='orange')
        plt.xlabel('Expense Category')
        plt.ylabel('Count')
        month_name = date(1990,month,1).strftime('%B')
        plt.title(f'Total Expense Category Counts for {department_name} in { month_name }')
        plt.savefig('./data/histogram_TotalExpenseCategoryCounts.png')
        plt.clf()

    @classmethod
    def expenses_totals(cls, month=datetime.today().month):
        report = Expense.search_expense(month=month)
        df = pd.DataFrame(report)
        grouped_data = df.groupby('department_name')['amount'].sum()

        plt.bar(grouped_data.index, grouped_data.values, alpha=0.5, color='orange')
        plt.xlabel('Department Names')
        plt.ylabel('Expense Amount')
        month_name = date(1990,month,1).strftime('%B')
        plt.title(f'Total Expenses in {month_name}')
        plt.savefig('./data/histogram_TotalExpenses.png')
        plt.clf()

    @classmethod
    def expenses_employees(cls, month=datetime.today().month):
        grouped_data = pd.DataFrame(Expense.search_expense(month=month)).groupby(['employee_id'])['amount'].sum()

        plt.bar(list(map(str, grouped_data.index)), grouped_data.values, alpha=0.5, color='orange')
        plt.xlabel('Employee IDs')
        plt.ylabel('Total Expense Amount')
        month_name = date(1990,month,1).strftime('%B')
        plt.title(f'Total Expenses for each employee in {month_name}')
        plt.savefig('./data/histogram_TotalExpensesEachEmployee.png')
        plt.clf()
