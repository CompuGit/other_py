from main import *

def main_menu(choice):
    if choice=='1':
        print(format(' Manage Employees ', '*^60'))
        print('''    
    1. Create 
    2. Modify 
    3. Find 
    4. Remove
    ''')
        while True:
            choice = x if (x:=input('=> ')) in ['1','2','3','4'] else ''
            if choice: break
            else: print('    [!] invalid choice.')
        operations('emp', choice)
    
    elif choice=='2':
        print(format(' Manage Departments ', '*^60'))
        print('''    
    1. Create 
    2. Modify 
    3. Find 
    4. Remove
    ''')
        while True:
            choice = x if (x:=input('=> ')) in ['1','2','3','4'] else ''
            if choice: break
            else: print('    [!] invalid choice.')
        operations('dep', choice)
    
    elif choice=='3':
        print(format(' Expenses and Reports ', '*^60'))
        print('''    
    1. Make an Expense 
    2. Search an Expense 
    3. Maximum Expense Employee
    4. Department's Over Budget
    5. Department's Maximum Expense
    6. Generate Monthly Expense Report 
    7. Generate Monthly Summary Report
    ''')
        while True:
            choice = x if (x:=input('=> ')) in ['1','2','3','4','5','6','7'] else ''
            if choice: break
            else: print('    [!] invalid choice.')
        operations('exp', choice)
    
    elif choice=='4':
        print(format(' Manage Budgets ', '*^60'))
        print('''    
    1. Update Budget for a Category by percent
    2. Update Budget for all Categories by percent
    ''')
        while True:
            choice = x if (x:=input('=> ')) in ['1','2'] else ''
            if choice: break
            else: print('    [!] invalid choice.')
        operations('cfo', choice)
    
    elif choice=='5':
        print(format(' Histograms ', '*^60'))
        print('''    
    1. Total Counts for each expense category of a department in a month
    2. Department Total epsense in a month
    3. Employee Total expense in a month
    ''')
        while True:
            choice = x if (x:=input('=> ')) in ['1','2','3'] else ''
            if choice: break
            else: print('    [!] invalid choice.')
        operations('hist', choice)

def operations(type_, choice):
    #employees operations
    if type_=='emp':
        if choice=='1':
            print(format(' Create Employee ', '+^60'))
            firstname = input('    Enter Firstname : ')
            lastname = input('    Enter Lastname : ')
            department_name = choose_department()
            rank = input('    Etner Rank : ')
            Employee.create(firstname=firstname, lastname=lastname, department_name = department_name, rank=rank)
            print(format('', '+^60'),'\n')

        elif choice=='2':
            print(format(' Modify Employee ', '+^60'))
            employee_id = int(input('    Enter Employee ID : '))
            firstname = input('    Enter Firstname (if not required leave blank): ')
            lastname = input('    Enter Lastname (if not required leave blank): ')
            department_name = choose_department()
            rank = input('    Enter Rank (if not required leave blank): ')
            Employee.modify(employee_id=employee_id, firstname=firstname, lastname=lastname, department_name = department_name, rank=rank)
            print(format('', '+^60'),'\n')

        elif choice=='3':
            print(format(' Find Employee ', '+^60'))
            employee_id = int(input('    Enter Employee ID : '))
            print(Employee.find(employee_id=employee_id))
            print(format('', '+^60'),'\n')
        
        elif choice=='4':
            print(format(' Remove Employee ', '+^60'))
            employee_id = int(input('    Enter Employee ID : '))
            ch = input('    Are you sure removing the Employee? (Y/N) : ')
            if ch.lower()=='y':
                Employee.remove(employee_id=employee_id)
            print(format('', '+^60'),'\n')
    
    #departments operations
    elif type_=='dep':
        if choice=='1':
            print(format(' Create Department ', '+^60'))
            department_name = input('    Enter Department Name : ')
            n = int(input('    Enter how amy Budgets categories you need to enter : '))
            budgets = {}
            for i in range(n):
                category = input('        Enter Category Name : ')
                amt = int(input('        Enter Budget : '))
                budgets[category] = amt
            
            Department.create(department_name=department_name, budgets=budgets)
            print(format('', '+^60'),'\n')

        elif choice=='2':
            print(format(' Modify Department ', '+^60'))
            department_name = choose_department()
            budgets = Department.departments[department_name]['budgets']
            for category, amt in budgets.items():
                amt = int(amt) if (amt:=input(f'{category} (amount={amt}) : ')) else amt
                budgets[category] = amt
            
            Department.modify(department_name=department_name, budgets=budgets)
            print(format('', '+^60'),'\n')

        elif choice=='3':
            print(format(' Find Department ', '+^60'))
            department_name = choose_department()
            print(Department.find(department_name=department_name))
            print(format('', '+^60'),'\n')
        
        elif choice=='4':
            print(format(' Remove Department ', '+^60'))
            department_name = choose_department()
            ch = input('    Are you sure removing the department? all the employees associated with this department are also removed. (Y/N) : ')
            if ch.lower()=='y':
                Department.remove(department_name=department_name)
            print(format('', '+^60'),'\n')
    
    #Expenses
    elif type_=='exp':
        if choice=='1':
            print(format(' Make an Expense ', '+^60'))
            employee_id = int(input('    Enter Employee Id : '))
            department_name = Employee.find(employee_id)['department_name']
            print(f'    Department Name : {department_name}')
            category = choose_category(department_name)
            amount = int(input('    Enter Expense Amount : '))
            today = datetime.today()
            timestamp =  datetime.timestamp(datetime.strptime(date_str, "%m-%d-%Y")) if (date_str:=input(f'        Enter Date(mm-dd-yyyy) when the expense made?  (defaut= {today}) : ')) else datetime.timestamp(today)
            Expense.make(employee_id, department_name, category, amount, timestamp)
            print(format('', '+^60'),'\n')
        
        elif choice=='2':
            print(format(' Search an Expense ', '+^60'))
            category = choose_category()
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.search(category=category,month=month))
            print(format('', '+^60'),'\n')

        elif choice=='3':
            print(format(' Maximux Expense Employee ', '+^60'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.emp_max_expense(month=month))
            print(format('', '+^60'),'\n')
        
        elif choice=='4':
            print(format(' Over Budget Departments ', '+^60'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.over_budget(month=month))
            print(format('', '+^60'),'\n')
        
        elif choice=='5':
            print(format(' Maximum Expense Department ', '+^60'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.dep_max_expense(month=month))
            print(format('', '+^60'),'\n')
        
        elif choice=='6':
            print(format(' Generate Monthly Expense Report ', '+^60'))
            department_name = choose_department(flag=1)
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.generate_expense_report(department_name=department_name, month=month))
            print('   [*] Report Generated.')
            print(format('', '+^60'),'\n')
        
        elif choice=='7':
            print(format(' Generate Monthly Summary Report ', '+^60'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            print(Expense.generate_summary_report(month=month))
            print('   [*] Report Generated.')
            print(format('', '+^60'),'\n')

    #CFO
    elif type_=='cfo':
        if choice=='1':
            print(format(' Update Budget for a Category ', '+^60'))
            category = choose_category(flag=1)
            percent = int(input('    Enter percentage number with sign : '))
            CFO.update_budget(category, percent)
            print('    [*] Budgets Updated.')
            print(format('', '+^60'),'\n')
        elif choice=='2':
            print(format(' Update Budget for all Categories ', '+^60'))
            percent = int(input('    Enter percentage number with sign : '))
            CFO.update_budget(percent=percent)
            print('    [*] Budgets Updated.')
            print(format('', '+^60'),'\n')
    
    #Histogram
    elif type_=='hist':
        if choice=='1':
            print(format(' Expense Category Total Counts', '+^60'))
            department_name = choose_department(flag=1)
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            Histogram.total_counts(department_name=department_name, month=month)
            print('    [*] Histogram Created.')
            print(format('', '+^60'),'\n')
        
        elif choice=='2':
            print(format(' Department Total Expense ', '+^60'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            Histogram.total_expenses(month=month)
            print('    [*] Histogram Created.')
            print(format('', '+^60'),'\n')
        
        elif choice=='3':
            print(format(' Employee Total Expense ', '+^60'))
            month = int(month) if (month:=input(f'        Enter month number (default {datetime.today().month}) : ')) else datetime.today().month
            Histogram.emp_expenses(month=month)
            print('    [*] Histogram Created.')
            print(format('', '+^60'),'\n')


def choose_department(flag=0):
    if not flag:
        departments = Department.departments.keys()
        print('    Choose a Department : ')
    else:
        departments = map(lambda exp: exp['department_name'], Expense.expenses)
        departments = list(set(departments))
        print('    Choose a Department from Expenses till: ')

    i=1
    for dep in departments:
        print(f'        {i}. {dep}')
        i+=1
        
    while True:
        choice = int(x) if (x:=input('    => ')) else 0
        if choice: break
        else: print('    [!] invalid choice.')
    return list(departments)[choice-1]


def choose_category(department_name=None, flag=0):
    if department_name:
        categories = list(Department.departments[department_name]['budgets'].keys())
        print('    Choose an Expense Category in the Department : ')
    elif not department_name and not flag:
        categories = map(lambda exp: exp['category'], Expense.expenses)
        categories = list(set(categories))
        print('    Choose an Expense Category from Expenses till: ')
    elif flag:
        categories = []
        for dep in Department.departments.keys() :
            categories += list(Department.departments[dep]['budgets'].keys())
        categories = list(set(categories))
        print('    Choose an Expense Category in all Departments : ')
    i=1
    for cat in categories:
        print(f'        {i}. {cat}')
        i+=1
    
    while True:
        choice = int(x) if (x:=input('    => ')) else 0
        if choice: break
        else: print('    [!] invalid choice.')

    return categories[choice-1]



if __name__=='__main__':

    print(format(' Expense Tracker ', '=^60'))
    print('''

    Select the below options to manage Employees/Department/Expenses.
    To quit the application enter 'q' or 'quit'
    ''')

    choice = '1'
    while True:
        print('''
                Main Menu
        
    1. Employees
    2. Departments
    3. Expenses
    4. Budgets
    5. Histograms
        ''')
        choice = input(' => ')
        if choice in ['q', 'quit']:
            print('Application data saved. Quitting...')
            break
        main_menu(choice)
