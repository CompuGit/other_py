import json
from time import time
from datetime import datetime, date
import json, copy
import matplotlib.pyplot as plt

class Department:
    departments_file = './data/departments.json'
    departments = json.load(open(departments_file,'r'))

    def __init__(self):
        raise TypeError("[!] Class cannot be instantiated.")

    @classmethod
    def find(cls, department_name):
        if department_name in cls.departments:
            return cls.departments[department_name]
        else:
            raise ValueError('[!] department not found.')

    @classmethod
    def create(cls, department_name, **kwargs):
        department_details = {'employees':[]}
        for k,v in kwargs.items():
            department_details[k] = v
        cls.departments[department_name] = department_details
        print('Department created : ',department_name)
        return cls.__save_state()

    @classmethod
    def modify(cls, department_name, **kwargs):
        department_details = cls.find(department_name)
        for k,v in kwargs.items():
            department_details[k] = v
        print('Department Modified : ',department_name)
        return cls.__save_state()
    
    @classmethod
    def remove(cls, department_name):
        if cls.find(department_name):
            emps = cls.departments[department_name]['employees']
            for emp in emps:
                Employee.remove(employee_id=emp)
            else:
                del cls.departments[department_name]
            print('Department Removed : ',department_name)
        return cls.__save_state()
    
    @classmethod
    def __save_state(cls):
        try:
            json.dump(cls.departments, open(cls.departments_file,'w'), indent=4)
            return True
        except Exception as e:
            print(e)
            return False

class Employee:
    employees_file = './data/employees.json'
    employees = json.load(open(employees_file,'r'))

    def __init__(self):
        raise TypeError("[!] Class cannot be instantiated.")

    @classmethod
    def find(cls, employee_id):
        for emp in cls.employees:
            if emp['employee_id'] == employee_id:
                return emp
        else:
            raise ValueError('[!] employee id not found.')

    @classmethod
    def create(cls, **kwargs):
        emp = { 'employee_id' : len(cls.employees) + 1 }
        for k,v in kwargs.items():
            emp[k] = v
        cls.employees.append(emp)
        print(kwargs)
        Department.departments[kwargs['department_name']]['employees'].append(emp['employee_id'])
        Department._Department__save_state()
        print()
        print('Employee created with id : ',emp['employee_id'])
        return cls.__save_state()

    @classmethod
    def modify(cls, employee_id, **kwargs):
        emp = cls.find(employee_id)
                
        if not kwargs['department_name']==emp['department_name']:
            
            Department.departments[emp['department_name']]['employees'].remove(employee_id)
            Department.departments[kwargs['department_name']]['employees'].append(employee_id)
            Department._Department__save_state()
            emp['department_name']=kwargs['department_name']
        
        for k,v in kwargs.items():
            if v:
                emp[k] = v
        
        print('Employee Modified with id : ',emp['employee_id'])
        return cls.__save_state()
    
    @classmethod
    def remove(cls, employee_id):
        emp = cls.find(employee_id)
        Department.departments[emp['department_name']]['employees'].remove(employee_id)
        Department._Department__save_state()
        cls.employees.remove( emp )
        print('Employee Removed with id : ',employee_id)
        return cls.__save_state()
    
    @classmethod
    def __save_state(cls):
        try:
            json.dump(cls.employees, open(cls.employees_file,'w'), indent=4)
            return True
        except Exception as e:
            print(e)
            return False

class Expense:
    expenses_file = './data/expenses.json'
    expenses = json.load(open(expenses_file,'r'))

    departments = Department.departments

    def __init__(self):
        raise TypeError("[!] Class cannot be instantiated.")
    
    @classmethod
    def make(cls, employee_id, department_name, category, amount, timestamp=time()):
        expense = {
            'employee_id' : employee_id,
            'department_name' : department_name,
            'category' : category,
            'amount' : amount,
            'timestamp' : timestamp
        }
        cls.expenses.append(expense)
        cls.__save_state(cls.expenses_file,cls.expenses)
    
    
    @classmethod
    def search(cls, category=None, department_name=None, month=datetime.today().month):
        expenses_list = copy.deepcopy(cls.expenses)
        
        if category:
            expenses_list = [ e for e in expenses_list if category==e.get('category',None)]
        
        if department_name:
            expenses_list = [ e for e in expenses_list if department_name==e.get('department_name',None)]

        for e in expenses_list:
            e['timestamp'] = datetime.fromtimestamp( e['timestamp'] ).strftime('%d-%m-%Y %H:%M:%S')
        
        if month:
            expenses_list = list(filter(lambda e: month==datetime.strptime(e['timestamp'], '%d-%m-%Y %H:%M:%S').month, expenses_list))
        

        return expenses_list


    @classmethod
    def __month_expenses(cls, department_name=None, month=datetime.today().month):
        if department_name:
            records = cls.search(department_name=department_name, month=month)
        else:
            records = cls.search(month=month)
        
        report = {}
        for rec in records:
            if rec['employee_id'] not in report:
                report[rec['employee_id']] = rec['amount']
            else:
                report[rec['employee_id']] += rec['amount']
        
        return report


    @classmethod
    def generate_expense_report(cls, department_name, month=datetime.today().month):
        report = cls.__month_expenses(department_name, month)
        cls.__save_state(f'./data/{department_name}_{month}_expense_report_.json', report)


    @classmethod
    def __summary_expense(cls, month=datetime.today().month):
        records = cls.search(month=month)
        report = {}
        for rec in records:
            department_name = rec['department_name']
            if department_name not in report:
                report[department_name] = { rec['category']: rec['amount'] }
            else:
                category = rec['category']
                if rec['category'] not in report[department_name]:
                    report[department_name][category] =  rec['amount']
                else:
                    report[department_name][category] +=  rec['amount']
        return report
    
    @classmethod
    def generate_summary_report(cls, month=datetime.today().month):
        report = cls.__summary_expense(month)
        cls.__save_state(f'./data/{month}_summary_report_.json', report)


    @classmethod
    def emp_max_expense(cls, month=datetime.today().month):
        report = cls.__month_expenses(month=month)
        emp_id = max(report, key=report.get)
        return {'employee_id' : emp_id}
    
    @classmethod
    def over_budget(cls, month=datetime.today().month):
        report = cls.__summary_expense(month)
        result = set()
        for dep in report.keys():
            _budgets = cls.departments[dep]['budgets']
            _expenses = report[dep]
            for key in _expenses:
                if key in _budgets and _expenses[key] > _budgets[key]:
                    result.add(dep)
        
        return list(result)

    @classmethod
    def dep_max_expense(cls, month=datetime.today().month):
        report = cls.__summary_expense(month)
        max_e = 0
        max_e_dep = ''
        for dep in report.keys():
            m = sum(report[dep].values())
            if m> max_e :
                max_e, max_e_dep = m, str(dep)
        return max_e_dep


    @classmethod
    def __save_state(cls, filename, report):
        try:
            json.dump(report, open(filename,'w'), indent=4)
            return True
        except Exception as e:
            print(e)
            return False

class CFO:

    @classmethod
    def update_budget(cls, category=None, percent=0):
        old_departments = copy.deepcopy(Department.departments)
        if category:
            for dep, details in Department.departments.items():
                if category in details['budgets']:
                    amt = details['budgets'][category]
                    details['budgets'][category] = amt + amt*( percent * 0.01)
        else:
            for dep, details in Department.departments.items():
                for category, amt in details['budgets'].items():
                    details['budgets'][category] = amt + amt*( percent * 0.01)
        
        cls.__save_state('./data/old/departments.json', old_departments)
        cls.__save_state(Department.departments_file, Department.departments)
        
    @classmethod
    def __save_state(cls, filename, report):
        try:
            json.dump(report, open(filename,'w'), indent=4)
            return True
        except Exception as e:
            print(e)
            return False

class Histogram:
    @classmethod
    def total_counts(cls, department_name, month=datetime.today().month):
        report = Expense.search(department_name=department_name, month=month)

        grouped_data = {}
        for d in report:
            if d['category'] not in grouped_data:
                grouped_data[d['category']] = 1
            else:
                grouped_data[d['category']] += 1
        
        plt.bar(grouped_data.keys(), grouped_data.values(), alpha=0.5, color='blue')
        plt.xlabel('Expense Category')
        plt.ylabel('Count')
        month_name = date(1990,month,1).strftime('%B')
        plt.title(f'Total Expense Category Counts for {department_name} in { month_name }')
        plt.savefig('./data/histogram_TotalExpenseCategoryCounts.png')
        plt.clf()

    @classmethod
    def total_expenses(cls, month=datetime.today().month):
        report = Expense.search(month=month)

        grouped_data = {}
        for d in report:
            if d['department_name'] not in grouped_data:
                grouped_data[d['department_name']] = d['amount']
            else:
                grouped_data[d['department_name']] += d['amount']
        
        plt.bar(grouped_data.keys(), grouped_data.values(), alpha=0.5, color='blue')
        plt.xlabel('Department Names')
        plt.ylabel('Expense Amount')
        month_name = date(1990,month,1).strftime('%B')
        plt.title(f'Total Expenses in {month_name}')
        plt.savefig('./data/histogram_TotalExpenses.png')
        plt.clf()

    @classmethod
    def emp_expenses(cls, month=datetime.today().month):
        grouped_data = Expense._Expense__month_expenses(month=month)
        plt.bar(list(map(str, grouped_data.keys())), grouped_data.values(), alpha=0.5, color='blue', )
        plt.xlabel('Employee IDs')
        plt.ylabel('Total Expense Amount')
        month_name = date(1990,month,1).strftime('%B')
        plt.title(f'Total Expenses for each employee in {month_name}')
        plt.savefig('./data/histogram_TotalExpensesEachEmployee.png')
        plt.clf()
