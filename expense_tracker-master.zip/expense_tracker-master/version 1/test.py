from main import *

if __name__=='__main__':
    pass
    #print(Employee.find(employee_id=1))
    #Employee.create(firstname='Clark', lastname='Kent', department_name='Engineering', rank='Supervisor')
    #Employee.modify(employee_id=4, firstname='Clark', lastname='Denvers', department_name='Sales')
    #Employee.remove(employee_id=4)

    #print(Department.find('Sales'))
    #Department.create('Accounting')
    #Department.modify('Accounting', budgets={'Transportation':500})
    #Department.remove('Sales')
    
    #Expense.make(employee_id=2, department_name='Engineering', category='Transportation', amount=400)
    #print(Expense.search(department_name='Sales'))
    #Expense.over_budget(month=3)
    #Expense.generate_expense_report('Engineering')
    #print(Expense._Expense__month_expenses()
    #print(Expense._Expense__summary_expense())
    #Expense.generate_expense_report('Engineering', month=3)
    #Expense.generate_summary_report(3)
    #print(Expense.emp_max_expense(4))
    #print(Expense.over_budget(month=4))
    #print(Expense.dep_max_expense(4))

    #CFO.update_budget(percent=-10)

    #Histogram.emp_expenses(4)
    #Histogram.total_counts('Engineering',3)
    #Histogram.total_expenses(3)
    