from abc import ABC, abstractmethod

class Book:
    def __init__(self, isbn, title, author = "", price = 0.0) -> None:
        self.__isbn = isbn
        self.__title = title

    def __eq__(self, __o: object) -> bool:
        pass

    def __str__(self) -> str:
        return f"Book isbn={self.__isbn}, title={self.__title}"

class BookList:
    def __init__(self) -> None:
        self.__books: list[Book] = []

    def add_book(self, book: Book):
        if book not in self.__books:
            self.__books.append(book)
    
    def __str__(self) -> str:
        output = ""
        for book in self.__books:
            output += str(book) + "\n"
        return output

class OrderItem:
    def __init__(self, isbn: str, quantity: int) -> None:
        pass


class Order:
    def __init__(self) -> None:
        self.__order_items: list[OrderItem] = []

    def add_item(self, isbn, quantity):
        self.__order_items.append(OrderItem(isbn, quantity))

class Invoice:
    def __init__(self, order: Order, book_list: BookList) -> None:
        pass


###########################################################################################
class Command:
    @abstractmethod
    def execute(self) -> str:
        pass

class DisplayBookListCommand(Command):
    def __init__(self, book_list: BookList) -> None:
        self.__book_list = book_list

    def execute(self) -> str:
        return str(self.__book_list)

class AddOrderItemCommand(Command):
    def __init__(self, order: Order) -> None:
        self.__order = order

    def execute(self) -> str:
        isbn = input("Enter isbn: ")
        quantity = int(input("Enter quantity: "))
        self.__order.add_item(isbn, quantity)

class DisplayInvoiceCommand(Command):
    pass

class Invoker:
    def __init__(self) -> None:
        self.__commands = []

    def add_command(self, command):
        self.__commands.append(command)

    def execute_command(self, command_no) -> str:
        return self.__commands[command_no-1].execute()

############################################################################################
class BookApplication:
    def __init__(self) -> None:
        self.__order = Order()
        self.__invoker = Invoker()
        self.__booklist = BookList()
        self.__booklist.add_book(Book("111", "C++"))
        self.__booklist.add_book(Book("222", "Java"))

    @property
    def order(self):
        return self.__order

    @property
    def booklist(self):
        return self.__booklist

    def add_command(self, command):
        self.__invoker.add_command(command)


    def show_menu(self):
        print("\n======== Menu  ============")
        print("1. Display Book List")
        print("2. Add Order Item")
        print("3. Display Invoice")
        print("4. Exit")

    def process_command(self, command_no):
        print(self.__invoker.execute_command(command_no))

def main():
    app = BookApplication()
    app.add_command(DisplayBookListCommand(app.booklist))
    app.add_command(AddOrderItemCommand(app.order))


    while True:
        app.show_menu()
        command_no = int(input("Please enter a command no: "))
        app.process_command(command_no)

if __name__ == "__main__":
    main()