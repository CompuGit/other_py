from abc import ABC, abstractmethod

class Book:
    def __init__(self, isbn, title, author="", price=0.0) -> None:
        self.__isbn = isbn
        self.__title = title
        self.__author = author
        self.__price = price
    
    @property
    def price(self):
        return self.__price

    def __eq__(self, o:object) -> bool:
        return self.__isbn == o.__isbn

    def __str__(self) -> str:
        return f"Book isbn={self.__isbn}, title={self.__title}, author={self.__author}, price={self.__price}"

class BookList:
    def __init__(self) -> None:
        self.__books: list[Book] = []

    def add_book(self, book: Book):
        if book not in self.__books:
            self.__books.append(book)

    def get_book(self, isbn):
        for book in self.__books:
            if book._Book__isbn == isbn:
                return book
        return None

    def __str__(self) -> str:
        output = ""
        for book in self.__books:
            output += str(book) + "\n"
        return output

class OrderItem:
    def __init__(self, isbn: str, quantity: int) -> None:
        self.__isbn = isbn
        self.__quantity = quantity
    
    @property
    def book_list(self):
        return self.__book_list
    
    @book_list.setter
    def book_list(self, book_list):
        self.__book_list = book_list
    
    @property   
    def book(self):
        self.__book = self.__book_list.get_book(self.__isbn)
        return self.__book

    @property
    def quantity(self):
        return self.__quantity

class Order:
    def __init__(self) -> None:
        self.__order_items: list[OrderItem] = []
        self.__book_list = []

    def add_item(self, isbn, quantity):
        __order = OrderItem(isbn, quantity)
        __order.book_list = self.__book_list
        self.__order_items.append(__order)

    def get_total_price(self):
        total_price = 0
        for order_item in self.__order_items:
            total_price += order_item.book.price * order_item.quantity
        return total_price

    def __str__(self) -> str:
        output = ""
        for order_item in self.__order_items:
            output += f"{order_item.book} x {order_item.quantity}\n"
        return output

class Invoice:
    def __init__(self, order: Order) -> None:
        self.__order = order

    def print_invoice(self):
        print("======== INVOICE =========")
        print(self.__order)
        total_price = self.__order.get_total_price()
        print(f"Total Price: {total_price}")

###########################################################################################
class Command:
    @abstractmethod
    def execute(self) -> str:
        pass

class DisplayBookListCommand(Command):
    def __init__(self, book_list: BookList) -> None:
        self.__book_list = book_list

    def execute(self) -> str:
        return str(self.__book_list)

class AddOrderItemCommand(Command):
    def __init__(self, order: Order) -> None:
        self.__order = order

    def execute(self) -> str:
        isbn = input("Enter isbn: ")
        quantity = int(input("Enter quantity: "))
        self.__order.add_item(isbn, quantity)
        return "Item added to the order"

class DisplayInvoiceCommand(Command):
    def __init__(self, order: Order) -> None:
        self.__order = order

    def execute(self) -> str:
        invoice = Invoice(self.__order)
        invoice.print_invoice()
        return ""

class Invoker:
    def __init__(self) -> None:
        self.__commands = []

    def add_command(self, command):
        self.__commands.append(command)

    def execute_command(self, command_no) -> str:
        return self.__commands[command_no-1].execute()

############################################################################################
class BookApplication:
    def __init__(self) -> None:
        self.__order = Order()
        self.__invoker = Invoker()
        self.__booklist = BookList()
        self.__order._Order__book_list = self.__booklist
        self.__booklist.add_book(Book("111", "C++", '', 45))
        self.__booklist.add_book(Book("222", "Java", '', 63))

    @property
    def order(self):
        return self.__order

    @property
    def booklist(self):
        return self.__booklist

    def add_command(self, command):
        self.__invoker.add_command(command)


    def show_menu(self):
        print("\n======== Menu  ============")
        print("1. Display Book List")
        print("2. Add Order Item")
        print("3. Display Invoice")
        print("4. Exit")

    def process_command(self, command_no):
        if command_no in [1,2,3]:
            print(self.__invoker.execute_command(command_no))
        elif command_no==4:
            print('Exitting the application.')
            exit()
        else:
            print('Invalid Command.')


def main():
    app = BookApplication()
    app.add_command(DisplayBookListCommand(app.booklist))
    app.add_command(AddOrderItemCommand(app.order))
    app.add_command(DisplayInvoiceCommand(app.order))

    while True:
        app.show_menu()
        command_no = int(input("Please enter a command no: "))
        app.process_command(command_no)

if __name__ == "__main__":
    main()